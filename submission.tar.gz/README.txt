The goal of the game is to navigate Buzz to the gold at the right of the
screen.  As the level increases, there will be more big bad UGA logos
blocking the way!  touching a UGA logo or a wall will put you back to level 0.
Right now, beat level 5 to beat the game.  From the start screen, press START to
begin.  Within a level, use arrow keys to navigate.  At any point, press
select to go back to the Start screen.
