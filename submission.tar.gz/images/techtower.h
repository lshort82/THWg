/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 techtower techtower.png 
 * Time-stamp: Thursday 04/11/2019, 21:07:24
 * 
 * Image Information
 * -----------------
 * techtower.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TECHTOWER_H
#define TECHTOWER_H

extern const unsigned short techtower[38400];
#define TECHTOWER_SIZE 76800
#define TECHTOWER_LENGTH 38400
#define TECHTOWER_WIDTH 240
#define TECHTOWER_HEIGHT 160

#endif

