/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=16x12 garbage garbage.png 
 * Time-stamp: Thursday 04/11/2019, 18:51:14
 * 
 * Image Information
 * -----------------
 * garbage.png 16@12
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GARBAGE_H
#define GARBAGE_H

extern const unsigned short garbage[192];
#define GARBAGE_SIZE 384
#define GARBAGE_LENGTH 192
#define GARBAGE_WIDTH 16
#define GARBAGE_HEIGHT 12

#endif

